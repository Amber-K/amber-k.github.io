#pragma once

class Paddle {
	public:
		Paddle();
		Paddle(float x, float y, float length, float height, ofColor color);
		
		void move(float x);
		void draw();

		void appear();
		void timeWarning();
		void disappear();

		float getX();
		float getY();
		float getLength();
		float getHeight();
		ofColor getColor();

	private:
		float x;
		float y;

		float length;
		float height;

		ofColor color;
};