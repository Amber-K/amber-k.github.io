#pragma once

class Brick {
	public:
		Brick();
		Brick(float x, float y, float length, float height, int health, int worth, ofColor color);

		void draw();
		void loseHealth();
		void remove();

		float getX();
		float getY();
		float getLength();
		float getHeight();
		int getHealth();
		int getWorth();

		bool isDestroyed();

	private:
		float x;
		float y;

		float length;
		float height;

		int health;
		int worth;

		ofColor color;
};