#include "ofMain.h"
#include "Paddle.h"

// Constructors

Paddle::Paddle() {
	x = ofGetWidth() / 2 - 25;
	y = ofGetHeight() / 2;
	length = 50;
	height = 5;
	color = ofColor(255);
}

Paddle::Paddle(float x, float y, float length, float height, ofColor color) {
	this->x = x;
	this->y = y;
	this->length = length;
	this->height = height;
	this->color = color;
}

// Movement

void Paddle::move(float x) {
	if (x + length / 2 <= ofGetWidth() && x >= length / 2) {
		this->x = x - length / 2;
	}
}

void Paddle::draw() {
	ofSetColor(color);
	ofDrawRectangle(x, y, length, height);
}

// Coloring

void Paddle::appear() {
	color = ofColor(255);
}

void Paddle::timeWarning() {
	color = ofColor(255, 244, 99);
}

void Paddle::disappear() {
	color = ofColor(0);
}

// Getters

float Paddle::getX() {
	return x;
}

float Paddle::getY() {
	return y;
}

float Paddle::getLength() {
	return length;
}

float Paddle::getHeight() {
	return height;
}

ofColor Paddle::getColor() {
	return color;
}