// Bust Out - Bounce a ball to break bricks in custom levels
// by Amber Kolar

#include "ofMain.h"
#include "ofApp.h"

int main() {
	ofSetupOpenGL(1024, 768, OF_WINDOW);
	ofRunApp(new ofApp());
}