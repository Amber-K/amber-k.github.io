#pragma once

class Powerup {
public:
	Powerup();
	Powerup(float x, float y, float length, float height, float ySpeed, ofColor color);

	void move();
	void drawWithoutImage();
	void drawWithImage(ofImage *image);

	void drop(float x, float y, float length, float height);
	void hide();
	void makeAvailable();

	bool hitPaddle(float x, float y, float length, float height);

	float getY();
	
private:
	float x;
	float y;

	float length;
	float height;

	float ySpeed;

	ofColor color;
};