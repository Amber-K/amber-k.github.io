#include "star.h"
#include "ship.h"
#include "ofMain.h"

struct star {
	float x;
	float y;
	float v;
	ofColor color;
	float w;
	float h;
};

struct star * star_construct(float x, float y, float v, ofColor color, float w, float h) {
	struct star * this_star = (struct star *) malloc(sizeof(struct star));
	this_star->x = x;
	this_star->y = y;
	this_star->v = v;
	this_star->color = color;
	this_star->w = w;
	this_star->h = h;

	return this_star;
}

void star_draw(struct star * s) {
	ofSetColor(s->color);
	ofDrawRectangle(s->x, s->y, s->w, s->h);
}

void star_move(struct star * s) {
	s->y += s->v;
}

void star_hyperspeed(struct star * s) {
	if (s->v < 20) {
		s->v *= 1.2;
	} else {
		if (s->h > 0.88 && s->h < 1000) {
			s->h += 100;
		} else if (s->h < 1000) {
			s->w = 0;
			s->h = 0;
		}
	}
}

void star_slow_down(struct star * s) {
	s->v = star_get_velocity();
	s->h = ofRandom(0.1, 1);
	s->w = s->h;
}

bool star_reaches_edge(struct star * s) {
	return ((s->y - s->h / 2) >= ofGetHeight());
}

void star_reset(struct star * s) {
	s->x = ofRandom(ofGetWidth());
	s->y = 0 - s->h;
}

float star_get_velocity() {
	float velocity = ofRandom(0.1, 2);
	float velocity_adjustment = ofRandom(100);

	if (velocity_adjustment <= 10) {
	} else if (velocity_adjustment <= 30) {
		velocity *= 0.75;
	}
	else if (velocity_adjustment <= 60) {
		velocity *= 0.5;
	}
	else if (velocity_adjustment <= 100) {
		velocity *= 0.25;
	}

	return velocity;
}