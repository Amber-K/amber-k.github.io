#pragma once
#include "ofMain.h"

struct star * star_construct(float x, float y, float v, ofColor color, float w, float h);

void star_draw(struct star * s);

void star_move(struct star * s);
void star_hyperspeed(struct star * s);
void star_slow_down(struct star * s);

bool star_reaches_edge(struct star * s);
void star_reset(struct star * s);

float star_get_velocity();