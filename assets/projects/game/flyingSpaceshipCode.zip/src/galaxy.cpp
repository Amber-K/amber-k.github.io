#include "galaxy.h"
#include "ofMain.h"

struct galaxy {
	float x;
	float y;
	float v;
	ofColor color;
	float w;
	float h;
	bool moving_fast;
};

struct galaxy * galaxy_construct(float x, float y, float v, ofColor color, float w, float h, bool moving_fast) {
	struct galaxy * this_galaxy = (struct galaxy *) malloc(sizeof(struct galaxy));
	this_galaxy->x = x;
	this_galaxy->y = y;
	this_galaxy->v = v;
	this_galaxy->color = color;
	this_galaxy->w = w;
	this_galaxy->h = h;
	this_galaxy->moving_fast = moving_fast;

	return this_galaxy;
}

void galaxy_move(struct galaxy * g) {
	g->y += g->v;
}

void galaxy_draw(struct galaxy * g, ofImage* image) {
	ofSetColor(g->color);
	image->draw(g->x, g->y, g->w, g->h);
}

void galaxy_hyperspeed(struct galaxy * g) {
	g->v *= 1.2;
	g->moving_fast = true;
}

void galaxy_slow_down(struct galaxy * g) {
	g->v = 0.025;
	g->moving_fast = false;
}

bool galaxy_in_hyperspeed(struct galaxy * g) {
	return g->moving_fast;
}

float galaxy_distance_traveled(struct galaxy * g) {
	return g->y;
}

bool galaxy_invisible(struct galaxy * g) {
	return g->w == 0;
}

void galaxy_appear(struct galaxy * g) {
	g->y = -185;
	g->w = 300;
	g->h = 200;
}