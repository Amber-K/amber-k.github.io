#pragma once

#include "ofMain.h"
#include "RuleSet.h"
#include "Paddle.h"
#include "Ball.h"

class ofApp : public ofBaseApp {

	public:
		ifstream fileReader;
		ofstream fileWriter;
		
		ofTrueTypeFont gameFont;

		RuleSet * sessionSettings;

		Paddle * player;
		Paddle * enemy;

		Ball * ball;
		Ball * life1;
		Ball * life2;
		Ball * life3;
		Ball * bullet;

		void setup();
		void update();
		void draw();

		void keyPressed(int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void mouseEntered(int x, int y);
		void mouseExited(int x, int y);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);
		
	private:
		enum GAME_STATE {
			START,
			SETTINGS,
			PLAY,
			GAME_OVER,
		};
		int gameState = START;

		float textX = ofGetWidth() / 9;
		ofColor textColor = ofColor(255);

		int instanceScore = 0;
		int highScoreInt;

		int timer = 0;
		int livesLeft = 3;
		int numberOfBullets = 0;
};
