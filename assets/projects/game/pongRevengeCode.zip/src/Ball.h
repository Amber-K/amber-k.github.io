#pragma once

class Ball {
	public:
		Ball();
		Ball(float x, float y, float radius, float speed, float xTrajectory, ofColor color);

		void move();
		void draw();
		void speedUp();
		void fire(float paddleX, float paddleY, float paddleLength);

		void deflect(float paddleSpeed, bool friction);
		void bounce();
		void reset(bool playerServes);
		void hide();

		bool atPlayer(float playerX, float playerY, float playerLength, float playerHeight);
		bool atEnemy(float enemyX, float enemyY, float enemyLength, float enemyHeight);
		bool atBorder();
		bool atPlayerGoal();
		bool atEnemyGoal();

		float xValue();
		float radiusValue();

	private:
		float x;
		float y;

		float radius;

		float speed;
		float xTrajectory;
		
		ofColor color;
};