#pragma once

class Paddle {
public:
	Paddle();
	Paddle(float length, float height, float x, float y, float speed, float acceleration, int temperature, ofColor color);

	void shrink();
	void thaw();
	void whiten();

	void move(bool glideValue);
	void draw();

	void pushLeft(bool glideValue);
	void pushRight(bool glideValue);
	void bounce();
	void freeze();
	void reset();

	bool atEdge();
	
	float xValue();
	float yValue();
	float lengthValue();
	float heightValue();
	float speedValue();
	float temperatureValue();

private:
	float length;
	float height;

	float x;
	float y;

	float speed;
	float acceleration;

	int temperature;
	ofColor color;
};