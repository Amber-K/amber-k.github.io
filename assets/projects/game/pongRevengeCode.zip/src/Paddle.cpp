#include "ofApp.h"

// Constructors

Paddle::Paddle() {
	length = 100;
	height = 20;

	x = ofGetWidth() / 2 - length / 2;
	y = ofGetHeight() / 2;

	speed = 0;
	acceleration = 0;

	temperature = 0;
	color = ofColor(0, 100, 255);
}

Paddle::Paddle(float length, float height, float x, float y, float speed, float acceleration, int temperature, ofColor color) {
	this->length = length;
	this->height = height;

	this->x = x;
	this->y = y;

	this->speed = speed;
	this->acceleration = acceleration;

	this->temperature = temperature;
	this->color = color;
}

// Disability Management

void Paddle::shrink() {
	if (length > 50) {
		x += (length - (length * 0.95)) / 2;
		length *= 0.95;
	}
}

void Paddle::thaw() {
	color = ofColor(0, 90, 255);
	++temperature;
}

void Paddle::whiten() {
	color = ofColor(255);
}

// Movement

void Paddle::move(bool glideValue) {
	if (glideValue) {
		speed += acceleration;
		speed *= 0.9;
		x += speed;
	}
}

void Paddle::draw() {
	ofSetColor(color);
	ofDrawRectangle(x, y, length, height);
}

// Direction

void Paddle::pushLeft(bool glideValue) {
	if (glideValue) {
		acceleration -= 0.1;
	} else {
		x -= 30;
		if (x <= 0) {
			x = 1;
		}
	}
}

void Paddle::pushRight(bool glideValue) {
	if (glideValue) {
		acceleration += 0.1;
	} else {
		x += 30;
		if (x + length >= ofGetWidth()) {
			x = ofGetWidth() - length - 1;
		}
	}
}

void Paddle::bounce() {
	x -= speed;
	speed /= -4;
	acceleration /= -4;
}

void Paddle::freeze() {
	temperature = -1000;
	speed = 0;
	acceleration = 0;
}

void Paddle::reset() {
	x = ofGetWidth() / 2 - length / 2;
	speed = 0;
	acceleration = 0;
	length = 160;
	temperature = 0;
}

// Position Check

bool Paddle::atEdge() {
	return x >= ofGetWidth() - length || x <= 0;
}

// Getters

float Paddle::xValue() {
	return x;
}

float Paddle::yValue() {
	return y;
}

float Paddle::lengthValue() {
	return length;
}

float Paddle::heightValue() {
	return height;
}

float Paddle::speedValue() {
	return speed;
}

float Paddle::temperatureValue() {
	return temperature;
}