#include "ofApp.h"

// Constructors

Ball::Ball() {
	x = ofGetWidth() / 2;
	y = ofGetHeight() / 2;

	radius = 10;

	speed = 0.5;
	xTrajectory = ofRandom(-0.5, 0.5);

	color = ofColor(255);
}

Ball::Ball(float x, float y, float radius, float speed, float xTrajectory, ofColor color) {
	this->x = x;
	this->y = y;

	this->radius = radius;

	this->speed = speed;
	this->xTrajectory = xTrajectory;

	this->color = color;
}

// Movement

void Ball::move() {
	x += xTrajectory;
	y += speed;
}

void Ball::draw() {
	ofSetColor(color);
	ofDrawCircle(x, y, radius);
}

void Ball::speedUp() {
	speed -= 0.1;
}

void Ball::fire(float paddleX, float paddleY, float paddleLength) {
	x = paddleX + paddleLength / 2;
	y = paddleY - radius;
	speed = -3;
}

// Direction

void Ball::deflect(float paddleSpeed, bool friction) {
	y -= speed;
	speed *= -1;
	if (friction) {
		xTrajectory += paddleSpeed;
	}
}

void Ball::bounce() {
	x -= xTrajectory;
	xTrajectory *= -1;
}

void Ball::reset(bool playerServes) {
	x = ofGetWidth() / 2;
	y = ofGetHeight() / 2;
	if (playerServes || speed > 0) {
		speed = 0.5;
	} else {
		speed = -0.5;
	}
	xTrajectory = ofRandom(-0.5, 0.5);
}

void Ball::hide() {
	x = ofGetWidth() * 2;
	speed = 0;
}

// Position Check

bool Ball::atPlayer(float playerX, float playerY, float playerLength, float playerHeight) {
	if (x >= playerX && x <= playerX + playerLength && y + radius >= playerY && y - radius <= playerY + playerHeight) {
		speed *= 1.1;
		return true;
	} else {
		return false;
	}
}

bool Ball::atEnemy(float enemyX, float enemyY, float enemyLength, float enemyHeight) {
	return x >= enemyX && x <= enemyX + enemyLength && y - radius <= enemyY + enemyHeight && y + radius >= enemyY;
}

bool Ball::atBorder() {
	return x + radius >= ofGetWidth() || x - radius <= 0;
}

bool Ball::atPlayerGoal() {
	return y >= ofGetHeight() + radius;
}

bool Ball::atEnemyGoal() {
	return y <= 0 - radius;
}

// Getters

float Ball::xValue() {
	return x;
}

float Ball::radiusValue() {
	return radius;
}