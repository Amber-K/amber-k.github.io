// Amber Kolar
// Unsigned integer to 16 bit binary converter

#include <iostream>
#include <cmath>

int main(int argc, const char * argv[]) {

	int values[16];
	int input;

	std::cout << "Input any unsigned integer from 0 to 65535.\n";
	std::cin >> input;

	if (input < 0 || input > 65535) {
		std::cout << "Your input is not an unsigned integer from 0 to 65535.\n";

	} else {
		for (int i = 15; i > -1; --i) {
			if (input >= std::pow(2, i)) {
				input -= pow(2, i);
				values[i] = 1;
			} else {
				values[i] = 0;
			}
		}

		std::cout << "The 16 bit binary equivalent of your integer is ";
		for (int i = 15; i > -1; --i) {
			std::cout << values[i];
		}
		std::cout << ".\n";
	}
	return 0;
}