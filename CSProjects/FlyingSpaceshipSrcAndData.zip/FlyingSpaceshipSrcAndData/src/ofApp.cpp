#include "ofApp.h"
#include "ship.h"
#include "galaxy.h"

const int NUMBER_OF_STARS = 1000;

void ofApp::setup() {
	ship_image.loadImage("ship.png");
	galaxy_image.loadImage("galaxy.png");
	nebula_image.loadImage("nebula.png");
	
	ship = ship_construct(ofGetWidth() / 2, ofGetHeight() - 150, 0, ofColor(255), 100, 115, 0);
	galaxy = galaxy_construct(ofGetWidth() / 10, -20, 0.025, ofColor(225), 300, 300, true);
	nebula = galaxy_construct(ofGetWidth() / 5 * 3, 0, 0.025, ofColor(225), 0, 0, true);

	stars = (struct star **) malloc( sizeof(struct star *) * NUMBER_OF_STARS);
	for (int i = 0; i < NUMBER_OF_STARS; ++i) {
		stars[i] = star_construct(ofRandom(ofGetWidth()), ofRandom(ofGetHeight()), star_get_velocity(), ofColor(ofRandom(235, 255), ofRandom(235, 255), ofRandom(235, 255)), ofRandom(0.1, 1), ofRandom(0.1, 1));
	}
}

void ofApp::update() {
	ship_move(ship);
	if (ship_reaches_edge(ship)) {
		ship_bounce(ship);
	}
	for (int i = 0; i < NUMBER_OF_STARS; ++i) {
		star_move(stars[i]);
		if (star_reaches_edge(stars[i])) {
			star_reset(stars[i]);
		}
	}
	galaxy_move(galaxy);
	galaxy_move(nebula);
}

void ofApp::draw() {
	ofBackground(0);
	galaxy_draw(galaxy, &galaxy_image);
	galaxy_draw(nebula, &nebula_image);
	for (int i = 0; i < NUMBER_OF_STARS; ++i) {
		star_draw(stars[i]);
	}
	ship_draw(ship, &ship_image);
	if (galaxy_invisible(nebula) == false && galaxy_distance_traveled(nebula) < -160) {
		ofDrawBitmapString("New Nebula Discovered!", ofGetWidth() / 5 * 3, 50);
	}
	if (galaxy_distance_traveled(galaxy) < 5) {
		ofDrawBitmapString("Created by Amber Kolar", ofGetWidth() / 2, ofGetHeight() / 2);
	} else if (galaxy_distance_traveled(galaxy) < 30) {
		ofDrawBitmapString("Use the arrow keys to move.", ofGetWidth() / 2, ofGetHeight() / 2);
	} else if (galaxy_distance_traveled(galaxy) < 55) {
		ofDrawBitmapString("Hold shift to boost.", ofGetWidth() / 2, ofGetHeight() / 2);
	}
}

void ofApp::keyPressed(int key) {
	if (key == OF_KEY_LEFT && galaxy_in_hyperspeed(galaxy) == false) {
		ship_thrust_left(ship);
	} else if (key == OF_KEY_RIGHT && galaxy_in_hyperspeed(galaxy) == false) {
		ship_thrust_right(ship);
	} else if (key == OF_KEY_LEFT || key == OF_KEY_RIGHT) {
		for (int i = 0; i < NUMBER_OF_STARS; ++i) {
			star_slow_down(stars[i]);
		}
		galaxy_slow_down(galaxy);
		galaxy_slow_down(nebula);
		if (galaxy_distance_traveled(nebula) > 1500 && galaxy_invisible(nebula)) {
			galaxy_appear(nebula);
		}
	}

	if (key == OF_KEY_SHIFT) {
		for (int i = 0; i < NUMBER_OF_STARS; ++i) {
			star_hyperspeed(stars[i]);
		}
		galaxy_hyperspeed(galaxy);
		galaxy_hyperspeed(nebula);
		ship_shake(ship);
	}
}

void ofApp::keyReleased(int key) {
	if (key == OF_KEY_SHIFT && galaxy_in_hyperspeed(galaxy)) {
		for (int i = 0; i < NUMBER_OF_STARS; ++i) {
			star_slow_down(stars[i]);
		}
		galaxy_slow_down(galaxy);
		galaxy_slow_down(nebula);
		if (galaxy_distance_traveled(nebula) > 1500 && galaxy_invisible(nebula)) {
			galaxy_appear(nebula);
		}
	}
}

void ofApp::mouseMoved(int x, int y) {

}

void ofApp::mouseDragged(int x, int y, int button) {

}

void ofApp::mousePressed(int x, int y, int button) {

}

void ofApp::mouseReleased(int x, int y, int button) {

}

void ofApp::mouseEntered(int x, int y) {

}

void ofApp::mouseExited(int x, int y) {

}

void ofApp::windowResized(int w, int h) {

}

void ofApp::gotMessage(ofMessage msg) {

}

void ofApp::dragEvent(ofDragInfo dragInfo) {

}