#pragma once
#include "ofMain.h"

struct galaxy * galaxy_construct(float x, float y, float v, ofColor color, float w, float h, bool moving_fast);

void galaxy_move(struct galaxy * g);
void galaxy_draw(struct galaxy * g, ofImage* image);

void galaxy_hyperspeed(struct galaxy * g);
void galaxy_slow_down(struct galaxy * g);

bool galaxy_in_hyperspeed(struct galaxy * g);
float galaxy_distance_traveled(struct galaxy * g);

bool galaxy_invisible(struct galaxy * g);
void galaxy_appear(struct galaxy * g);