#pragma once
#include "ofMain.h"

struct ship * ship_construct(float x, float y, float v, ofColor color, float w, float h, float t);

void ship_draw(struct ship * s, ofImage* image);

void ship_move(struct ship * s);
void ship_thrust_right(struct ship * s);
void ship_thrust_left(struct ship * s);

bool ship_reaches_edge(struct ship * s);
void ship_bounce(struct ship * s);

void ship_shake(struct ship * s);