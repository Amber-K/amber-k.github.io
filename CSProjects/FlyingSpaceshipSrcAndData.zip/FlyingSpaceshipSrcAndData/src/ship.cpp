#include "ship.h"
#include "ofMain.h"

static const float ACCELERATION = 0.1;

struct ship {
	float x;
	float y;
	float v;
	ofColor color;
	float w;
	float h;
	float t;
};

struct ship * ship_construct(float x, float y, float v, ofColor color, float w, float h, float t) {
	struct ship * this_ship = (struct ship *) malloc(sizeof(struct ship));
	this_ship->x = x;
	this_ship->y = y;
	this_ship->v = v;
	this_ship->color = color;
	this_ship->w = w;
	this_ship->h = h;
	this_ship->t = t;

	return this_ship;
}

void ship_draw(struct ship * s, ofImage *image) {
	ofSetColor(s->color);
	image->draw(s->x, s->y, s->w, s->h);
}

void ship_move(struct ship * s) {
	s->x += s->v;
	s->v *= 0.999;
	
	s->y += 0.02 * cos(s->t);
	s->t += 0.001;
}

void ship_thrust_right(struct ship * s) {
	s->v += ACCELERATION;
}

void ship_thrust_left(struct ship * s) {
	s->v -= ACCELERATION;
}

bool ship_reaches_edge(struct ship * s) {
	if (s->x <= 0) {
		s->x = 0;
		return true;
	}
	else if ((s->x + s->w) >= ofGetWidth()) {
		s->x = ofGetWidth() - s->w;
		return true;
	}
	return false;
}

void ship_bounce(struct ship * s) {
	s->v *= -0.5;
}

void ship_shake(struct ship * s) {
	float direction_value = ofRandom(100);

	if (s->x > ofGetWindowWidth() / 2 + s->w) {
		if (direction_value <= 60) {
			s->x -= 3;
		} else {
			s->x += 3;
		}
	} else {
		if (direction_value <= 40) {
			s->x -= 3;
		} else {
			s->x += 3;
		}
	}
}