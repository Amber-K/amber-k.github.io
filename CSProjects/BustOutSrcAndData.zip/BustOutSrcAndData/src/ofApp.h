#pragma once
#include "ofMain.h"
#include "Paddle.h"
#include "Ball.h"
#include "Brick.h"
#include "Powerup.h"
#include "Star.h"

class ofApp : public ofBaseApp{
	public:
		ofTrueTypeFont gameFont;
		ofSoundPlayer paddleBounceSound;
		ofSoundPlayer wallBounceSound;
		ofSoundPlayer brickBounceSound;
		ofSoundPlayer backgroundMusic;
		ofImage secondBallImage;
		ofImage yongBulletOpenImage;
		ofImage yongBulletClosedImage;

		Paddle *player;
		Ball *initialBall;
		Paddle *mirrorPaddle;
		Ball *secondBall;
		Ball *yongBullet;
		vector<Brick*> bricks;
		Star ** stars;
		Powerup *mirrorPaddleIcon;
		Powerup *secondBallIcon;
		Powerup *yongBulletIcon;

		void setup();
		void loadBricks(int gameLevel);
		void update();
		void draw();
		void incrementClock();
		void pickPowerup(float x, float y, float length, float height);

		void keyPressed(int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void mouseEntered(int x, int y);
		void mouseExited(int x, int y);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);

	private:
		enum GAME_STATE {
			LEVEL_1,
			LEVEL_2,
			LEVEL_3,
			YOU_WIN,
			GAME_OVER,
			ERROR_MESSAGE,
		};
		int gameState = LEVEL_1;
		int clock = 0;
		int livesLeft = 3;
		int score = 0;
		int currentBrick = 1;
		float currentBrickX = ofGetWidth() / 168;
		float currentBrickY = 0;
		int NUMBER_OF_STARS = 500;
};
