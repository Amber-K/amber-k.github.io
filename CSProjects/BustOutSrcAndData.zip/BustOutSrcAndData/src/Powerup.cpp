#include "ofMain.h"
#include "Powerup.h"

// Constructors

Powerup::Powerup() {
	x = 0;
	y = ofGetHeight() * 2;
	length = 50;
	height = 50;
	ySpeed = 0.5;
	color = ofColor(255);
}

Powerup::Powerup(float x, float y, float length, float height, float ySpeed, ofColor color) {
	this->x = x;
	this->y = y;
	this->length = length;
	this->height = height;
	this->ySpeed = ySpeed;
	this->color = color;
}

// Movement

void Powerup::move() {
	y += ySpeed;
}

void Powerup::drawWithoutImage() {
	ofSetColor(color);
	ofDrawRectangle(x, y, length, height);
}

void Powerup::drawWithImage(ofImage *image) {
	ofSetColor(color);
	image->draw(x, y, length, height);
}

// Stages of Use

void Powerup::drop(float x, float y, float length, float height) {
	this->x = length / 2 + x - (this->length / 2);
	this->y = height / 2 + y - (this->height / 2);
	ySpeed = 0.5;
}

void Powerup::hide() {
	x = -50;
	y = -50;
	ySpeed = 0;
}

void Powerup::makeAvailable() {
	y = ofGetHeight() * 2;
}

// Collisions

bool Powerup::hitPaddle(float x, float y, float length, float height) {
	return this->x < x + length && this->x + this->length > x && this->y + this->height > y && this->y < y + height;
}

// Getters

float Powerup::getY() {
	return y;
}