#include "ofMain.h"
#include "Star.h"

// Constructors

Star::Star() {
	x = ofRandom(ofGetWidth());
	y = ofRandom(ofGetHeight());
	radius = ofRandom(0.1, 1);
	ySpeed = selectYSpeed();
	color = ofColor(ofRandom(235, 255), ofRandom(235, 255), ofRandom(235, 255));
}

Star::Star(float x, float y, float radius, float ySpeed, ofColor color) {
	this->x = x;
	this->y = y;
	this->radius = radius;
	this->ySpeed = ySpeed;
	this->color = color;
}

float Star::selectYSpeed() {
	float ySpeed = ofRandom(0.1, 2);
	float ySpeedAdjustment = ofRandom(100);
	if (ySpeedAdjustment <= 10) {
		// Do nothing.
	}
	else if (ySpeedAdjustment <= 30) {
		ySpeed *= 0.75;
	}
	else if (ySpeedAdjustment <= 60) {
		ySpeed *= 0.5;
	}
	else if (ySpeedAdjustment <= 100) {
		ySpeed *= 0.25;
	}
	return ySpeed;
}

// Movement

void Star::move() {
	y += ySpeed;
}

void Star::draw() {
	ofSetColor(color);
	ofDrawCircle(x, y, radius);
}

void Star::reset() {
	x = ofRandom(ofGetWidth());
	y = 0 - radius;
}

// Checking

bool Star::offScreen() {
	return y + radius > ofGetHeight();
}