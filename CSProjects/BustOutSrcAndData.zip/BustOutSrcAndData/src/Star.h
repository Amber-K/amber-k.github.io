#pragma once

class Star {
public:
	Star();
	Star(float x, float y, float radius, float ySpeed, ofColor color);
	float selectYSpeed();

	void move();
	void draw();
	void reset();

	bool offScreen();

private:
	float x;
	float y;

	float radius;

	float ySpeed;

	ofColor color;
};