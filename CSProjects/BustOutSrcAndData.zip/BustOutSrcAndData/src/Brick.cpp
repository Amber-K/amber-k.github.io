#include "ofMain.h"
#include "Brick.h"

// Constructors

Brick::Brick() {
	x = ofGetWidth() / 2;
	y = ofGetHeight() / 2;
	length = 100;
	height = 50;
	health = 3;
	worth = 8;
	color = ofColor(255);
}

Brick::Brick(float x, float y, float length, float height, int health, int worth, ofColor color) {
	this->x = x;
	this->y = y;
	this->length = length;
	this->height = height;
	this->health = health;
	this->worth = worth;
	this->color = color;
}

// Graphics

void Brick::draw() {
	ofSetColor(color);
	ofDrawRectangle(x, y, length, height);
}

void Brick::loseHealth() {
	--health;
	if (color == ofColor(255, 244, 99)) {
		color = ofColor(255);
	} else if (color == ofColor(50, 163, 255)) {
		color = ofColor(255, 244, 99);
	} else if (color == ofColor(255, 58, 58)) {
		color = ofColor(50, 163, 255);
	} else if (color == ofColor(255, 172, 48)) {
		color = ofColor(255, 58, 58);
	}
	if (health <= 0) {
		this->remove();
	}
}

void Brick::remove() {
	x = -50;
	y = -50;
}

// Getters

float Brick::getX() {
	return x;
}

float Brick::getY() {
	return y;
}

float Brick::getLength() {
	return length;
}

float Brick::getHeight() {
	return height;
}

int Brick::getHealth() {
	return health;
}

int Brick::getWorth() {
	return worth;
}

// Checking

bool Brick::isDestroyed() {
	return x == -50;
}