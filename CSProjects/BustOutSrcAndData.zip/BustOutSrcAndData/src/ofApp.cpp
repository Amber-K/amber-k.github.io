#include "ofApp.h"

void ofApp::setup() {
	gameFont.load("AnotherBrick.ttf", 48);
	paddleBounceSound.load("paddleBounce.aiff");
	paddleBounceSound.setMultiPlay(true);
	wallBounceSound.load("wallBounce.wav");
	wallBounceSound.setMultiPlay(true);
	brickBounceSound.load("brickBounce.aiff");
	brickBounceSound.setMultiPlay(true);
	backgroundMusic.load("TheLift.mp3");
	backgroundMusic.setLoop(true);
	backgroundMusic.play();
	secondBallImage.loadImage("secondBall.png");
	yongBulletOpenImage.loadImage("yongBulletOpen.png");
	yongBulletClosedImage.loadImage("yongBulletClosed.png");
	player = new Paddle(ofGetWidth() / 2 - 50, ofGetHeight() / 8 * 7, 100, 10, ofColor(255));
	initialBall = new Ball();
	mirrorPaddle = new Paddle(ofGetWidth() / 2 - 50, ofGetHeight() / 8 * 7, 100, 10, ofColor(0));
	secondBall = new Ball(-50, ofGetHeight() * 2, 5, 0, 0, ofColor(255));
	yongBullet = new Ball(-50, ofGetHeight() * 2, 50, 0, 0, ofColor(255));
	loadBricks(42);
	stars = new Star *[NUMBER_OF_STARS];
	for (int i = 0; i < NUMBER_OF_STARS; ++i) {
		stars[i] = new Star();
	}
	mirrorPaddleIcon = new Powerup(0, ofGetHeight() * 2, 50, 5, 0, ofColor(255));
	secondBallIcon = new Powerup(0, ofGetHeight() * 2, 40, 40, 0, ofColor(255));
	yongBulletIcon = new Powerup(0, ofGetHeight() * 2, 50, 50, 0, ofColor(255));
	ofBackground(0);
}

void ofApp::loadBricks(int gameLevel) {
	ofBuffer level = ofBufferFromFile("01.txt");
	if (gameLevel == LEVEL_2) {
		level = ofBufferFromFile("02.txt");
	} else if (gameLevel == LEVEL_3) {
		level = ofBufferFromFile("03.txt");
	} else if (gameLevel == YOU_WIN || gameLevel == GAME_OVER) {
		return;
	}
	for (auto line : level.getLines()) {
		for (int i = 0; i < line.size(); ++i) {
			char brickColor = line[i];
			Brick *brick;
			if (brickColor == 'w') {
				brick = new Brick(currentBrickX, currentBrickY, ofGetWidth() / 13, ofGetHeight() / 16, 1, 1, ofColor(255));
			} else if (brickColor == 'y') {
				brick = new Brick(currentBrickX, currentBrickY, ofGetWidth() / 13, ofGetHeight() / 16, 2, 3, ofColor(255, 244, 99));
			} else if (brickColor == 'b') {
				brick = new Brick(currentBrickX, currentBrickY, ofGetWidth() / 13, ofGetHeight() / 16, 3, 9, ofColor(50, 163, 255));
			} else if (brickColor == 'r') {
				brick = new Brick(currentBrickX, currentBrickY, ofGetWidth() / 13, ofGetHeight() / 16, 4, 27, ofColor(255, 58, 58));
			} else if (brickColor == ' ') {
				brick = new Brick(currentBrickX, currentBrickY, ofGetWidth() / 13, ofGetHeight() / 16, 0, 0, ofColor(255, 172, 48));
			} else {
				gameState = ERROR_MESSAGE;
			}
			++currentBrick;
			currentBrickX += ofGetWidth() / 12;
			if (currentBrick > 12) {
				currentBrick = 1;
				currentBrickX = ofGetWidth() / 168;
				currentBrickY += ofGetHeight() / 15;
			}
			bricks.push_back(brick);
		}
	}
}

void ofApp::update() {
	for (int i = 0; i < NUMBER_OF_STARS; ++i) {
		stars[i]->move();
		if (stars[i]->offScreen()) {
			stars[i]->reset();
		}
	}
	if (gameState == LEVEL_1 || gameState == LEVEL_2 || gameState == LEVEL_3) {
		incrementClock();
		initialBall->move();
		if (!initialBall->offScreen()) {
			initialBall->bounceOffWall(&wallBounceSound);
		}
		initialBall->bounceOffPaddle(player->getX(), player->getY(), player->getLength(), player->getHeight(), &paddleBounceSound);
		secondBall->move();
		if (!secondBall->offScreen()) {
			secondBall->bounceOffWall(&wallBounceSound);
		}
		secondBall->bounceOffPaddle(player->getX(), player->getY(), player->getLength(), player->getHeight(), &paddleBounceSound);
		if (mirrorPaddle->getColor() != ofColor(0)) {
			initialBall->bounceOffPaddle(mirrorPaddle->getX(), mirrorPaddle->getY(), mirrorPaddle->getLength(), mirrorPaddle->getHeight(), &paddleBounceSound);
			secondBall->bounceOffPaddle(mirrorPaddle->getX(), mirrorPaddle->getY(), mirrorPaddle->getLength(), mirrorPaddle->getHeight(), &paddleBounceSound);
		}
		yongBullet->move();
		mirrorPaddleIcon->move();
		secondBallIcon->move();
		yongBulletIcon->move();
		if (mirrorPaddleIcon->hitPaddle(player->getX(), player->getY(), player->getLength(), player->getHeight())) {
			mirrorPaddle->appear();
			mirrorPaddleIcon->hide();
			clock = 0;
		}
		if (secondBallIcon->hitPaddle(player->getX(), player->getY(), player->getLength(), player->getHeight()) || (mirrorPaddle->getColor() != ofColor(0) && secondBallIcon->hitPaddle(mirrorPaddle->getX(), mirrorPaddle->getY(), mirrorPaddle->getLength(), mirrorPaddle->getHeight()))) {
			secondBall->reset();
			secondBallIcon->hide();
		}
		if (yongBulletIcon->hitPaddle(player->getX(), player->getY(), player->getLength(), player->getHeight())) {
			yongBullet->fire(player->getX(), player->getY(), player->getLength());
			yongBulletIcon->hide();
		} else if (mirrorPaddle->getColor() != ofColor(0) && yongBulletIcon->hitPaddle(mirrorPaddle->getX(), mirrorPaddle->getY(), mirrorPaddle->getLength(), mirrorPaddle->getHeight())) {
			yongBullet->fire(mirrorPaddle->getX(), mirrorPaddle->getY(), mirrorPaddle->getLength());
			yongBulletIcon->hide();
		}
		if (mirrorPaddle->getColor() != ofColor(0) && clock >= 6000 && clock <= 7000) {
			mirrorPaddle->timeWarning();
		} else if (clock >= 7000) {
			mirrorPaddle->disappear();
			mirrorPaddleIcon->makeAvailable();
		}
		if (initialBall->offScreen() && secondBall->offScreen()) {
			initialBall->reset();
			secondBallIcon->makeAvailable();
			--livesLeft;
			if (livesLeft < 1) {
				for (int i = 0; i < bricks.size(); ++i) {
					bricks.at(i)->remove();
				}
				mirrorPaddle->disappear();
				yongBullet->stop();
				mirrorPaddleIcon->makeAvailable();
				yongBulletIcon->makeAvailable();
				gameState = GAME_OVER;
			}
		}
		if (yongBullet->done()) {
			yongBulletIcon->makeAvailable();
			yongBullet->stop();
		}
		bool allDestroyed = true;
		for (int i = 0; i < bricks.size(); ++i) {
			if (!bricks.at(i)->isDestroyed()) {
				allDestroyed = false;
			}
			if (bricks.at(i)->getHealth() == 0) {
				bricks.at(i)->remove();
			}
			if (initialBall->touchingBrick(bricks.at(i)->getX(), bricks.at(i)->getY(), bricks.at(i)->getLength(), bricks.at(i)->getHeight())) {
				initialBall->bounceOffBrick(bricks.at(i)->getX(), bricks.at(i)->getLength(), &brickBounceSound);
				if (bricks.at(i)->getHealth() == 1) {
					pickPowerup(bricks.at(i)->getX(), bricks.at(i)->getY(), bricks.at(i)->getLength(), bricks.at(i)->getHeight());
					score += bricks.at(i)->getWorth();
				}
				bricks.at(i)->loseHealth();
			}
			if (secondBall->touchingBrick(bricks.at(i)->getX(), bricks.at(i)->getY(), bricks.at(i)->getLength(), bricks.at(i)->getHeight())) {
				secondBall->bounceOffBrick(bricks.at(i)->getX(), bricks.at(i)->getLength(), &brickBounceSound);
				if (bricks.at(i)->getHealth() == 1) {
					pickPowerup(bricks.at(i)->getX(), bricks.at(i)->getY(), bricks.at(i)->getLength(), bricks.at(i)->getHeight());
					score += bricks.at(i)->getWorth();
				}
				bricks.at(i)->loseHealth();
			}
			if (yongBullet->shootingBrick(bricks.at(i)->getX(), bricks.at(i)->getY(), bricks.at(i)->getLength(), bricks.at(i)->getHeight())) {
				if (bricks.at(i)->getHealth() == 1) {
					brickBounceSound.play();
					pickPowerup(bricks.at(i)->getX(), bricks.at(i)->getY(), bricks.at(i)->getLength(), bricks.at(i)->getHeight());
					score += bricks.at(i)->getWorth();
				}
				bricks.at(i)->loseHealth();
			}
		}
		if (allDestroyed && gameState != GAME_OVER) {
			++gameState;
			initialBall->reset();
			mirrorPaddle->disappear();
			secondBall->stop();
			yongBullet->stop();
			mirrorPaddleIcon->makeAvailable();
			secondBallIcon->makeAvailable();
			yongBulletIcon->makeAvailable();
			currentBrickY = 0;
			loadBricks(gameState);
		}
	}
}

void ofApp::draw() {
	if (gameState == LEVEL_1 || gameState == LEVEL_2 || gameState == LEVEL_3) {
		mirrorPaddle->draw();
	}
	for (int i = 0; i < NUMBER_OF_STARS; ++i) {
		stars[i]->draw();
	}
	ofSetColor(255, 58, 58);
	if (gameState == LEVEL_1 || gameState == LEVEL_2 || gameState == LEVEL_3) {
		gameFont.drawString("LEVEL: " + ofToString(gameState + 1), ofGetWidth() / 2.5, ofGetHeight() / 7 * 3);
		gameFont.drawString("LIVES: " + ofToString(livesLeft), ofGetWidth() / 2.5, ofGetHeight() / 7 * 4);
		gameFont.drawString("SCORE: " + ofToString(score), ofGetWidth() / 2.7, ofGetHeight() / 7 * 5);
		player->draw();
		initialBall->drawWithoutImage();
		secondBall->drawWithoutImage();
		if (clock % 2 == 0) {
			yongBullet->drawWithImage(&yongBulletClosedImage);
		} else {
			yongBullet->drawWithImage(&yongBulletOpenImage);
		}
		for (int i = 0; i < bricks.size(); ++i) {
			bricks.at(i)->draw();
		}
		mirrorPaddleIcon->drawWithoutImage();
		secondBallIcon->drawWithImage(&secondBallImage);
		yongBulletIcon->drawWithImage(&yongBulletClosedImage);
	} else if (gameState == YOU_WIN) {
		gameFont.drawString("CONGRATULATIONS! YOU WIN!!", ofGetWidth() / 8, ofGetHeight() / 6 * 2);
		gameFont.drawString("TOTAL SCORE: " + ofToString(score), ofGetWidth() / 3.5, ofGetHeight() / 6 * 3);
		gameFont.drawString("PRESS ENTER TO PLAY AGAIN", ofGetWidth() / 7.5, ofGetHeight() / 6 * 4);
	} else if (gameState == GAME_OVER) {
		gameFont.drawString("GAME OVER", ofGetWidth() / 2.7, ofGetHeight() / 6 * 2);
		gameFont.drawString("TOTAL SCORE: " + ofToString(score), ofGetWidth() / 3.5, ofGetHeight() / 6 * 3);
		gameFont.drawString("PRESS ENTER TO PLAY AGAIN", ofGetWidth() / 7.5, ofGetHeight() / 6 * 4);
	} else if (gameState == ERROR_MESSAGE) {
		gameFont.drawString("LEVEL TEXT FILE MADE INCORRECTLY", ofGetWidth() / 20, ofGetHeight() / 2);
	}
}

void ofApp::pickPowerup(float x, float y, float length, float height) {
	float dropValue = ofRandom(0, 14);
	if (dropValue <= 1 && mirrorPaddleIcon->getY() > ofGetHeight()) {
		mirrorPaddleIcon->drop(x, y, length, height);
	} else if (dropValue <= 2 && secondBallIcon->getY() > ofGetHeight()) {
		secondBallIcon->drop(x, y, length, height);
	} else if (dropValue <= 3 && yongBulletIcon->getY() > ofGetHeight()) {
		yongBulletIcon->drop(x, y, length, height);
	}
}

void ofApp::incrementClock() {
	++clock;
	if (clock >= 8000) {
		clock = 0;
	}
}

void ofApp::keyPressed(int key) {
	if ((gameState == YOU_WIN || gameState == GAME_OVER) && key == OF_KEY_RETURN) {
		gameState = LEVEL_1;
		livesLeft = 3;
		score = 0;
		currentBrickY = 0;
		loadBricks(gameState);
	}
}

void ofApp::keyReleased(int key) {
}

void ofApp::mouseMoved(int x, int y) {
	if (gameState == LEVEL_1 || LEVEL_2 || LEVEL_3) {
		mirrorPaddle->move(ofGetWidth() - x);
		player->move(x);
	}
}

void ofApp::mouseDragged(int x, int y, int button) {
}

void ofApp::mousePressed(int x, int y, int button) {
}

void ofApp::mouseReleased(int x, int y, int button) {
}

void ofApp::mouseEntered(int x, int y) {
}

void ofApp::mouseExited(int x, int y) {
}

void ofApp::windowResized(int w, int h) {
}

void ofApp::gotMessage(ofMessage msg) {
}

void ofApp::dragEvent(ofDragInfo dragInfo) {
}