#pragma once

class Ball {
	public:
		Ball();
		Ball(float x, float y, float radius, float xSpeed, float ySpeed, ofColor color);

		void move();
		void drawWithImage(ofImage *image);
		void drawWithoutImage();
		void reset();
		void fire(float x, float y, float length);
		void stop();

		void bounceOffPaddle(float x, float y, float length, float height, ofSoundPlayer *sound);
		void bounceOffWall(ofSoundPlayer *sound);
		void bounceOffBrick(float x, float length, ofSoundPlayer *sound);

		bool touchingBrick(float x, float y, float length, float height);
		bool shootingBrick(float x, float y, float length, float height);
		bool offScreen();
		bool done();

	private:
		float x;
		float y;
		
		float radius;

		float xSpeed;
		float ySpeed;

		ofColor color;
};