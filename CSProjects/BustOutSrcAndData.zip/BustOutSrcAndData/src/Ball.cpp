#include "ofMain.h"
#include "Ball.h"

// Constructors

Ball::Ball() {
	x = ofGetWidth() / 2;
	y = ofGetHeight() / 2;
	radius = 5;
	xSpeed = ofRandom(-0.5, 0.5);
	ySpeed = 1;
	color = ofColor(255);
}

Ball::Ball(float x, float y, float radius, float xSpeed, float ySpeed, ofColor color) {
	this->x = x;
	this->y = y;
	this->radius = radius;
	this->xSpeed = xSpeed;
	this->ySpeed = ySpeed;
	this->color = color;
}

// Movement

void Ball::move() {
	x += xSpeed;
	y += ySpeed;
}

void Ball::drawWithImage(ofImage *image) {
	ofSetColor(color);
	image->draw(x - (radius / 2), y - (radius / 2), radius, radius);
}

void Ball::drawWithoutImage() {
	ofSetColor(color);
	ofDrawCircle(x, y, radius);
}

void Ball::reset() {
	x = ofGetWidth() / 2;
	y = ofGetHeight() / 2;
	xSpeed = ofRandom(-0.5, 0.5);
	ySpeed = 1;
}

void Ball::fire(float x, float y, float length) {
	this->x = length / 2 + x;
	this->y = y;
	ySpeed = -1;
}

void Ball::stop() {
	y = ofGetHeight() * 2;
	xSpeed = 0;
	ySpeed = 0;
}

// Collisions

void Ball::bounceOffPaddle(float x, float y, float length, float height, ofSoundPlayer *sound) {
	if (this->x - radius < x + length && this->x + radius > x && this->y + radius > y && this->y - radius < y + height) {
		sound->play();
		ySpeed *= -1;
		xSpeed += ofRandom(-0.4, 0.4);
		if (this->x - radius < x + (length / 5)) {
			xSpeed -= 0.8;
		} else if (this->x - radius < x + (length / 5 * 2)) {
			xSpeed -= 0.4;
		} else if (this->x - radius < x + (length / 5 * 3)) {
			// Do nothing.
		} else if (this->x - radius < x + (length / 5 * 4)) {
			xSpeed += 0.4;
		} else if (this->x - radius < x + length) {
			xSpeed += 0.8;
		}
		this->y += ySpeed;
		this->x += xSpeed;
	}
}

void Ball::bounceOffWall(ofSoundPlayer *sound) {
	if (x - radius <= 0 || x + radius >= ofGetWidth()) {
		sound->play();
		xSpeed *= -1;
		ySpeed += ofRandom(-0.4, 0.4);
	} else if (y - radius <= 0) {
		sound->play();
		ySpeed *= -1;
		xSpeed += ofRandom(-0.4, 0.4);
	}
}

void Ball::bounceOffBrick(float x, float length, ofSoundPlayer *sound) {
	sound->play();
	if (this->x - radius < x + length - 2 && this->x + radius > x + 2) {
		ySpeed *= -1;
		xSpeed += ofRandom(-0.4, 0.4);
		this->x += xSpeed;
		y += ySpeed;
	} else {
		xSpeed *= -1;
		ySpeed += ofRandom(-0.4, 0.4);
		this->x += xSpeed;
		y += ySpeed;
	}
}

// Checking

bool Ball::touchingBrick(float x, float y, float length, float height) {
	return this->x - radius < x + length && this->x + radius > x && this->y + radius > y && this->y - radius < y + height;
}

bool Ball::shootingBrick(float x, float y, float length, float height) {
	return this->x < x + length && this->x > x && this->y > y && this->y < y + height;
}

bool Ball::offScreen() {
	return y + radius > ofGetHeight();
}

bool Ball::done() {
	return y + radius < 0;
}