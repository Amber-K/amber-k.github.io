#pragma once

class RuleSet {
	public:
		RuleSet();
		RuleSet(bool paddleShrink, bool friction, bool playerServes, bool payForBullet, bool playerGlide);

		void togglePaddleShrink();
		void toggleFriction();
		void togglePlayerServes();
		void togglePayForBullet();
		void togglePlayerGlide();

		bool paddleShrinkValue();
		bool frictionValue();
		bool playerServesValue();
		bool payForBulletValue();
		bool playerGlideValue();

	private:
		bool paddleShrink;
		bool friction;
		bool playerServes;
		bool payForBullet;
		bool playerGlide;
};