#include "ofApp.h"

void ofApp::setup() {
	fileReader.open(ofToDataPath("HighScore.txt"));
	string highScoreString;
	getline(fileReader, highScoreString);
	fileReader.close();
	highScoreInt = stoi(highScoreString);

	gameFont.load("strasua.ttf", 24);

	ofBackground(0);

	sessionSettings = new RuleSet();
	player = new Paddle(160, 20, ofGetWidth() / 2 - 80, ofGetHeight() / 9 * 8, 0, 0, 0, ofColor(255));
	enemy = new Paddle(160, 20, ofGetWidth() / 2 - 80, ofGetHeight() / 9, 0, 0, 0, ofColor(255));
	ball = new Ball();
	life1 = new Ball(ofGetWidth() / 2 - 25, ofGetHeight() / 6 * 4, 10, 0, 0, ofColor(255));
	life2 = new Ball(ofGetWidth() / 2 + 25, ofGetHeight() / 6 * 4, 10, 0, 0, ofColor(255));
	bullet = new Ball(ofGetWidth() * 2, 0, 10, 0, 0, ofColor(0, 90, 255));
}

void ofApp::update() {
	if (gameState == START) {
		instanceScore = 0;

	} else if (gameState == PLAY) {
		if (enemy->temperatureValue() >= 0) {
			enemy->whiten();
			if (timer <= 100) {
				++timer;
			} else {
				if (ball->xValue() + ball->radiusValue() >= enemy->xValue()) {
					enemy->pushRight(true);
				}
				if (ball->xValue() - ball->radiusValue() <= enemy->xValue() + enemy->lengthValue()) {
					enemy->pushLeft(true);
				}
				timer = 0;
			}
		} else {
			enemy->thaw();
		}
		if (player->atEdge()) {
			player->bounce();
		}
		if (enemy->atEdge()) {
			enemy->bounce();
		}
		if (bullet->atEnemy(enemy->xValue(), enemy->yValue(), enemy->lengthValue(), enemy->heightValue())) {
			enemy->freeze();
			bullet->hide();
		}
		if (ball->atBorder()) {
			ball->bounce();
		} else if (ball->atPlayer(player->xValue(), player->yValue(), player->lengthValue(), player->heightValue())) {
			++instanceScore;
			if (!sessionSettings->payForBulletValue() && instanceScore % 10 == 0) {
				++numberOfBullets;
			}
			ball->deflect(player->speedValue(), sessionSettings->frictionValue());
			if (sessionSettings->paddleShrinkValue()) {
				player->shrink();
			}
			ball->speedUp();
		} else if (ball->atEnemy(enemy->xValue(), enemy->yValue(), enemy->lengthValue(), enemy->heightValue())) {
			ball->deflect(enemy->speedValue(), sessionSettings->frictionValue());
		} else if (ball->atPlayerGoal()) {
			--livesLeft;
			if (livesLeft <= 0) {
				gameState = GAME_OVER;
				livesLeft = 3;
			}
			ball->reset(sessionSettings->playerServesValue());
			bullet->hide();
			player->reset();
			enemy->reset();
		} else if (ball->atEnemyGoal()) {
			ball->reset(sessionSettings->playerServesValue());
			++livesLeft;
			for (int i = 0; i < 5; ++i) {
				++instanceScore;
				if (!sessionSettings->payForBulletValue() && instanceScore % 10 == 0) {
					++numberOfBullets;
				}
			}
		}
		player->move(sessionSettings->playerGlideValue());
		enemy->move(true);
		ball->move();
		bullet->move();

	} else if (gameState == GAME_OVER) {
		numberOfBullets = 0;
		if (highScoreInt < instanceScore) {
			highScoreInt = instanceScore;
			fileWriter.open(ofToDataPath("HighScore.txt"));
			fileWriter << highScoreInt;
			fileWriter.close();
		}
	}
}

void ofApp::draw() {
	if (gameState == START) {
		ofSetColor(textColor);
		ofDrawBitmapString("Made by Amber Kolar", 20, 20);
		gameFont.drawString("Pong's Revenge", textX, ofGetHeight() / 6);
		gameFont.drawString("High Score: " + ofToString(highScoreInt), textX, ofGetHeight() / 6 * 2);
		gameFont.drawString("Press Enter or Click to Start", textX, ofGetHeight() / 6 * 3);
		gameFont.drawString("Press S for Settings", textX, ofGetHeight() / 6 * 4);
		ofDrawBitmapString("Instructions:", textX, ofGetHeight() / 6 * 5);
		if (sessionSettings->playerGlideValue()) {
			ofDrawBitmapString("Tap the left and right arrow keys to speed up in either direction.", textX, ofGetHeight() / 6 * 5 + 20);
		} else {
			ofDrawBitmapString("Press and hold the left and right arrow keys to move.", textX, ofGetHeight() / 6 * 5 + 20);
		}
		if (sessionSettings->payForBulletValue()) {
			ofDrawBitmapString("Press Enter while in-game to spend 5 points and fire a bullet.", textX, ofGetHeight() / 6 * 5 + 40);
		} else {
			ofDrawBitmapString("Press Enter when you have a bullet to fire it.", textX, ofGetHeight() / 6 * 5 + 40);
		}

	} else if (gameState == SETTINGS) {
		ofSetColor(textColor);
		if (sessionSettings->paddleShrinkValue()) {
			gameFont.drawString("Press A to Disable Player Paddle Shrinking", textX, ofGetHeight() / 6);
		} else {
			gameFont.drawString("Press A to Enable Player Paddle Shrinking", textX, ofGetHeight() / 6);
		}
		if (sessionSettings->frictionValue()) {
			gameFont.drawString("Press B to Disable Friction", textX, ofGetHeight() / 7 * 2);
		} else {
			gameFont.drawString("Press B to Enable Friction", textX, ofGetHeight() / 7 * 2);
		}
		if (sessionSettings->playerServesValue()) {
			gameFont.drawString("Press C to Make the Opponet Serve Too", textX, ofGetHeight() / 7 * 3);
		} else {
			gameFont.drawString("Press C to Handle All the Serving", textX, ofGetHeight() / 7 * 3);
		}
		if (sessionSettings->payForBulletValue()) {
			gameFont.drawString("Press D to Collect Bullets for Free (1 Every 10 Points)", textX, ofGetHeight() / 7 * 4);
		} else {
			gameFont.drawString("Press D to Make Bullets Cost 5 Points Each", textX, ofGetHeight() / 7 * 4);
		}
		if (sessionSettings->playerGlideValue()) {
			gameFont.drawString("Press E to Disable Player Gliding", textX, ofGetHeight() / 7 * 5);
		} else {
			gameFont.drawString("Press E to Enable Player Gliding", textX, ofGetHeight() / 7 * 5);
		}
		gameFont.drawString("Press Enter or Click to Start", textX, ofGetHeight() / 7 * 6);

	} else if (gameState == PLAY) {
		ofSetColor(textColor);
		gameFont.drawString("Score: " + ofToString(instanceScore), ofGetWidth() / 7 * 3, ofGetHeight() / 6 * 2);
		if (!sessionSettings->payForBulletValue()) {
			gameFont.drawString("Bullets: " + ofToString(numberOfBullets), ofGetWidth() / 7 * 3, ofGetHeight() / 6 * 3);
		}
		player->draw();
		enemy->draw();
		ball->draw();
		if (livesLeft >= 2 && livesLeft < 4) {
			life2->draw();
		} else if (livesLeft >= 4) {
			gameFont.drawString("Lives: " + ofToString(livesLeft), ofGetWidth() / 7 * 3, ofGetHeight() / 6 * 4);
		}
		if (livesLeft == 3) {
			life1->draw();
		}
		bullet->draw();

	} else if (gameState == GAME_OVER) {
		ofSetColor(textColor);
		gameFont.drawString("Game Over", textX, ofGetHeight() / 5);
		gameFont.drawString("Your Score: " + ofToString(instanceScore), textX, ofGetHeight() / 5 * 2);
		if (instanceScore == highScoreInt) {
			if (timer <= 50) {
				gameFont.drawString("New High Score!", textX, ofGetHeight() / 5 * 3);
			}
			if (timer <= 100) {
				++timer;
			} else {
				timer = 0;
			}
		} else {
			gameFont.drawString("High Score: " + ofToString(highScoreInt), textX, ofGetHeight() / 5 * 3);
		}
		gameFont.drawString("Press Enter or Click to Return to Start Screen", textX, ofGetHeight() / 5 * 4);
	}
}

void ofApp::keyPressed(int key) {
	if (gameState == START) {
		if (key == OF_KEY_RETURN) {
			gameState = PLAY;
		} else if (key == 's') {
			gameState = SETTINGS;
		}

	} else if (gameState == SETTINGS) {
		if (key == 'a') {
			sessionSettings->togglePaddleShrink();
		} else if (key == 'b') {
			sessionSettings->toggleFriction();
		} else if (key == 'c') {
			sessionSettings->togglePlayerServes();
		} else if (key == 'd') {
			sessionSettings->togglePayForBullet();
		} else if (key == 'e') {
			sessionSettings->togglePlayerGlide();
		} else if (key == OF_KEY_RETURN) {
			gameState = PLAY;
		}

	} else if (gameState == PLAY) {
		if (key == OF_KEY_LEFT) {
			player->pushLeft(sessionSettings->playerGlideValue());
		} else if (key == OF_KEY_RIGHT) {
			player->pushRight(sessionSettings->playerGlideValue());
		} else if (key == OF_KEY_RETURN) {
			if (sessionSettings->payForBulletValue() && instanceScore >= 5) {
				instanceScore -= 5;
				bullet->fire(player->xValue(), player->yValue(), player->lengthValue());
			} else if (!sessionSettings->payForBulletValue() && numberOfBullets > 0) {
				--numberOfBullets;
				bullet->fire(player->xValue(), player->yValue(), player->lengthValue());
			}
		}

	} else if (gameState == GAME_OVER && key == OF_KEY_RETURN) {
		gameState = START;
	}
}

void ofApp::keyReleased(int key) {
}

void ofApp::mouseMoved(int x, int y) {
}

void ofApp::mouseDragged(int x, int y, int button) {
}

void ofApp::mousePressed(int x, int y, int button) {
	if (gameState == START) {
		gameState = PLAY;

	} else if (gameState == SETTINGS) {
		gameState = PLAY;

	} else if (gameState == GAME_OVER) {
		gameState = START;
	}
}

void ofApp::mouseReleased(int x, int y, int button) {
}

void ofApp::mouseEntered(int x, int y) {
}

void ofApp::mouseExited(int x, int y) {
}

void ofApp::windowResized(int w, int h) {
}

void ofApp::gotMessage(ofMessage msg) {
}

void ofApp::dragEvent(ofDragInfo dragInfo) {
}