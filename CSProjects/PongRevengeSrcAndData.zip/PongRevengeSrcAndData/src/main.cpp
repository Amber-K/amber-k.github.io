// Pong's Revenge - The classic game, Pong, but with a twist.
// by Amber Kolar

#include "ofMain.h"
#include "ofApp.h"

int main() {
	ofSetupOpenGL(1024,768,OF_WINDOW);
	ofRunApp(new ofApp());
}