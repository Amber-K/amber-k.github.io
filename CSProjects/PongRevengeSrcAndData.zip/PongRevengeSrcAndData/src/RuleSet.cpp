#include "ofApp.h"

// Constructors

RuleSet::RuleSet() {
	paddleShrink = true;
	friction = true;
	playerServes = true;
	payForBullet = true;
	playerGlide = true;
}

RuleSet::RuleSet(bool paddleShrink, bool friction, bool playerServes, bool payForBullet, bool playerGlide) {
	this->paddleShrink = paddleShrink;
	this->friction = friction;
	this->playerServes = playerServes;
	this->payForBullet = payForBullet;
	this->playerGlide = playerGlide;
}

// Toggles

void RuleSet::togglePaddleShrink() {
	paddleShrink = !paddleShrink;
}

void RuleSet::toggleFriction() {
	friction = !friction;
}

void RuleSet::togglePlayerServes() {
	playerServes = !playerServes;
}

void RuleSet::togglePayForBullet() {
	payForBullet = !payForBullet;
}

void RuleSet::togglePlayerGlide() {
	playerGlide = !playerGlide;
}

// Getters

bool RuleSet::paddleShrinkValue() {
	return paddleShrink;
}

bool RuleSet::frictionValue() {
	return friction;
}

bool RuleSet::playerServesValue() {
	return playerServes;
}

bool RuleSet::payForBulletValue() {
	return payForBullet;
}

bool RuleSet::playerGlideValue() {
	return playerGlide;
}